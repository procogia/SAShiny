## ----include=FALSE------------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## -----------------------------------------------------------------------------
library(SAShiny)

# Write a minimal contract and program to a temporary directory.
dir <- tempfile("sashiny-")
dir.create(dir)
writeLines(c(
  "sashiny: 1",
  "program: program.sas",
  "title: Minimal",
  "outputs:",
  "  log:",
  "    type: log"
), file.path(dir, "contract.sashiny.yml"))
writeLines("proc print data=sashelp.class; run;", file.path(dir, "program.sas"))

## -----------------------------------------------------------------------------
contract <- sas_contract(file.path(dir, "contract.sashiny.yml"))
issues <- sas_validate(contract)
length(issues)  # 0 means valid

## -----------------------------------------------------------------------------
engine <- sas_engine_mock()
result <- sas_run(contract, list(), engine)
result$status

## -----------------------------------------------------------------------------
oda <- sas_connect("oda", region = "us1")
oda$cfg$authkey

